package com.app.community.network.response;

/**
 * Created  on 29/09/17 .
 */

public class Meta {
    public int code;
    public String message;
}
