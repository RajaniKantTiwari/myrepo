package com.app.community.network.response.dashboard.meeting;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by Amul on 28/12/17.
 */

public class MeetingEventDetailResponse implements Parcelable {
   private ArrayList<MeetingEventResponse> contentList;
   private int totalPages;
   private int numberOfResults;
   private int nextPage;

   public MeetingEventDetailResponse(){

   }

    protected MeetingEventDetailResponse(Parcel in) {
        totalPages = in.readInt();
        numberOfResults = in.readInt();
        nextPage = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(totalPages);
        dest.writeInt(numberOfResults);
        dest.writeInt(nextPage);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<MeetingEventDetailResponse> CREATOR = new Creator<MeetingEventDetailResponse>() {
        @Override
        public MeetingEventDetailResponse createFromParcel(Parcel in) {
            return new MeetingEventDetailResponse(in);
        }

        @Override
        public MeetingEventDetailResponse[] newArray(int size) {
            return new MeetingEventDetailResponse[size];
        }
    };

    public ArrayList<MeetingEventResponse> getContentList() {
        return contentList;
    }

    public void setContentList(ArrayList<MeetingEventResponse> contentList) {
        this.contentList = contentList;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getNumberOfResults() {
        return numberOfResults;
    }

    public void setNumberOfResults(int numberOfResults) {
        this.numberOfResults = numberOfResults;
    }

    public int getNextPage() {
        return nextPage;
    }

    public void setNextPage(int nextPage) {
        this.nextPage = nextPage;
    }
}
