package com.app.community.network.response.dashboard.meeting;

import android.databinding.Bindable;
import android.databinding.Observable;
import android.databinding.PropertyChangeRegistry;
import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Amul on 28/12/17.
 */

public class MeetingEventResponse implements Parcelable,Observable {
    private int id;
    private String title;
    private String address;
    private double lat;
    private double lng;
    private long date;
    private long fromTime;
    private long toTime;

    private PropertyChangeRegistry registry = new PropertyChangeRegistry();
    public MeetingEventResponse(){

    }

    protected MeetingEventResponse(Parcel in) {
        id = in.readInt();
        title = in.readString();
        address = in.readString();
        lat = in.readDouble();
        lng = in.readDouble();
        date = in.readLong();
        fromTime = in.readLong();
        toTime = in.readLong();
    }

    public static final Creator<MeetingEventResponse> CREATOR = new Creator<MeetingEventResponse>() {
        @Override
        public MeetingEventResponse createFromParcel(Parcel in) {
            return new MeetingEventResponse(in);
        }

        @Override
        public MeetingEventResponse[] newArray(int size) {
            return new MeetingEventResponse[size];
        }
    };
    @Bindable
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    @Bindable
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    @Bindable
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    @Bindable
    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }
    @Bindable
    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }
    @Bindable
    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }
    @Bindable
    public long getfromTime() {
        return fromTime;
    }

    public void setfromTime(long fromTime) {
        this.fromTime = fromTime;
    }
    @Bindable
    public long gettoTime() {
        return toTime;
    }

    public void settoTime(long toTime) {
        this.toTime = toTime;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(address);
        dest.writeDouble(lat);
        dest.writeDouble(lng);
        dest.writeLong(date);
        dest.writeLong(fromTime);
        dest.writeLong(toTime);
    }

    @Override
    public void addOnPropertyChangedCallback(OnPropertyChangedCallback onPropertyChangedCallback) {
        registry.add(onPropertyChangedCallback);
    }

    @Override
    public void removeOnPropertyChangedCallback(OnPropertyChangedCallback onPropertyChangedCallback) {
        registry.remove(onPropertyChangedCallback);

    }
}
