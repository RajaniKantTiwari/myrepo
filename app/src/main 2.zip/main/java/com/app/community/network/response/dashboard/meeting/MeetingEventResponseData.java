package com.app.community.network.response.dashboard.meeting;


import com.app.community.network.response.BaseResponse;

/**
 * Created by Amul on 28/12/17.
 */

public class MeetingEventResponseData extends BaseResponse {
    private MeetingEventDetailResponse data;

    public MeetingEventDetailResponse getData() {
        return data;
    }

    public void setData(MeetingEventDetailResponse data) {
        this.data = data;
    }
}
