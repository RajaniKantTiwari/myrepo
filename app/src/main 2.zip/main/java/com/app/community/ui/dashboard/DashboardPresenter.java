package com.app.community.ui.dashboard;

import android.app.Activity;


import com.app.community.network.DefaultApiObserver;
import com.app.community.network.Repository;
import com.app.community.network.request.dashboard.MeetingEventRequest;
import com.app.community.network.response.dashboard.meeting.MeetingEventResponseData;
import com.app.community.ui.base.MvpView;
import com.app.community.ui.base.Presenter;

import javax.inject.Inject;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;


public class DashboardPresenter implements Presenter<MvpView> {


    private MvpView mView;
    private Repository mRepository;


    @Override
    public void attachView(MvpView view) {
        mView = view;
    }

    @Inject
    public DashboardPresenter(Repository repository) {
        this.mRepository = repository;
    }

    public void getMeetingEventList(Activity activity, MeetingEventRequest request) {
       /* mView.showProgress();
        mRepository.getMeetingEventList(request).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribeWith(new DefaultApiObserver<MeetingEventResponseData>(activity) {
            @Override
            public void onResponse(MeetingEventResponseData response) {
                mView.hideProgress();
                switch (response.getResponseCode()) {
                    case Constants.HTTP_RESPONSE_CODE:
                        mView.onSuccess(response,responseCode);
                        break;
                    default:
                        CommonUtils.showToast(activity, response.getMessage());
                        mView.onError(response.getMessage(),responseCode);
                }
            }

            @Override
            public void onError(Throwable call, BaseResponse baseResponse) {
                mView.hideProgress();
                mView.onError(baseResponse.getMessage(),responseCode);
            }
        });*/
    }
}
