package com.app.community.ui.dashboard.home.adapter;

import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;


import com.app.community.R;
import com.app.community.databinding.ItemProductRowBinding;
import com.app.community.network.response.dashboard.meeting.MeetingEventResponse;
import com.app.community.utils.CommonUtils;

import java.util.ArrayList;

/**
 * Created by Amul on 27/12/17.
 */

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.LOcationViewHolder> {
    private final LayoutInflater mInflator;
    private ArrayList<MeetingEventResponse> meetingEventList;

    public ProductAdapter(AppCompatActivity activity){
        mInflator=LayoutInflater.from(activity);
    }

    @Override
    public LOcationViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       ItemProductRowBinding mBinding= DataBindingUtil.inflate(mInflator, R.layout.item_product_row,parent,false);
        return new LOcationViewHolder(mBinding);
    }

    @Override
    public void onBindViewHolder(LOcationViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 7;
    }

    public void setLocationList(ArrayList<MeetingEventResponse> meetingEventList) {
        this.meetingEventList=meetingEventList;
        notifyDataSetChanged();
    }

    class LOcationViewHolder extends RecyclerView.ViewHolder{
        private ItemProductRowBinding itmView;
        public LOcationViewHolder(ItemProductRowBinding itemView) {
            super(itemView.getRoot());
            this.itmView=itemView;
        }

    }
}
