package com.app.community.ui.dashboard.home.event;


import com.app.community.network.response.dashboard.meeting.MeetingEventResponse;

import java.util.ArrayList;

/**
 * Created by Amul on 27/12/17.
 */

public class MeetingEvent {
    //use 1 for meeting 2 for event
    private int meetingEvent;
    //use 1 for list 2 for map
    private int listMap;

    private ArrayList<MeetingEventResponse> meetingEventList;

    public ArrayList<MeetingEventResponse> getMeetingEventList() {
        return meetingEventList;
    }

    public void setMeetingEventList(ArrayList<MeetingEventResponse> meetingEventList) {
        this.meetingEventList = meetingEventList;
    }

    public int getListMap() {
        return listMap;
    }

    public void setListMap(int listMap) {
        this.listMap = listMap;
    }

    public int getMeetingEvent() {
        return meetingEvent;
    }

    public void setMeetingEvent(int meetingEvent) {
        this.meetingEvent = meetingEvent;
    }

}
