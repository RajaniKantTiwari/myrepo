package com.app.community.ui.dashboard.home.expendedrecyclerview.holder;

import android.support.v7.widget.RecyclerView;
import android.view.View;


/**
 * ViewHolder for
 */
public class ChildViewHolder extends RecyclerView.ViewHolder {

  public ChildViewHolder(View itemView) {
    super(itemView);
  }
}
