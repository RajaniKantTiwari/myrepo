package com.app.community.ui.dashboard.home.fragment;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.community.R;
import com.app.community.databinding.FragmentHomeBinding;
import com.app.community.network.request.dashboard.MeetingEventRequest;
import com.app.community.network.response.BaseResponse;
import com.app.community.network.response.dashboard.meeting.MeetingEventDetailResponse;
import com.app.community.network.response.dashboard.meeting.MeetingEventResponse;
import com.app.community.network.response.dashboard.meeting.MeetingEventResponseData;
import com.app.community.ui.base.BaseActivity;
import com.app.community.ui.dashboard.DashboardFragment;
import com.app.community.ui.dashboard.DashboardPresenter;
import com.app.community.ui.dashboard.home.event.MeetingEvent;
import com.app.community.ui.location.GPSTracker;
import com.app.community.utils.CommonUtils;
import com.app.community.utils.GeneralConstant;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.maps.model.LatLng;


import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

import javax.inject.Inject;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;
import static com.app.community.utils.GeneralConstant.PERMISSIONS_REQUEST_LOCATION;

/**
 * Created by Amul on 13/11/17.
 */
public class HomeFragment extends DashboardFragment {

    @Inject
    DashboardPresenter presenter;
    private MeetingEvent event;
    private double latitude;
    private double longitude;
    private GPSTracker gpsTracker;

    private boolean isLatLongPresent;

    private ArrayList<MeetingEventResponse> productList;
    FragmentHomeBinding mBinding;
    private int pageNumber;

    public static HomeFragment newInstance() {
        return new HomeFragment();
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false);
        addFragment();
        //ExplicitIntent.getsInstance().navigateTo(getBaseActivity(),MainActivity.class);
        return mBinding.getRoot();
    }

    private void addFragment() {
        event = new MeetingEvent();
        event.setListMap(GeneralConstant.LIST_PRODUCT);
        productList = new ArrayList<>();
        getBaseActivity().pushChildFragment(getChildFragmentManager(), GeneralConstant.FRAGMENTS.PRODUCT_MAP_FRAGMENT,
                null, R.id.container, true, false, BaseActivity.AnimationType.NONE);
        getBaseActivity().pushChildFragment(getChildFragmentManager(), GeneralConstant.FRAGMENTS.PRODUCT_LIST,
                null, R.id.container, true, false, BaseActivity.AnimationType.NONE);

    }

    @Override
    public void initializeData() {

    }

    private void callApiForProduct(int pageNumber) {
        MeetingEventRequest request = new MeetingEventRequest();
        request.setLat(latitude);
        request.setLng(longitude);
        request.setPage(pageNumber);
        request.setSize(GeneralConstant.PAGE_SIZE);
        getPresenter().getMeetingEventList(getBaseActivity(), request);
    }

    @Override
    public void setListener() {
        mBinding.listButton.setOnClickListener(this);

    }

    @Override
    public String getFragmentName() {
        return HomeFragment.class.getSimpleName();
    }

    @Override
    public void attachView() {
        getPresenter().attachView(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    @Override
    public void onClick(View view) {
       if (view == mBinding.listButton) {
            listMapConversion();
        }
    }


    private void getCurrentLocation() {
        // create class object
        gpsTracker = new GPSTracker(getBaseActivity());
        if (ActivityCompat.checkSelfPermission(getBaseActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(getBaseActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            gpsTracker.requestPermission(getBaseActivity());
        } else if (gpsTracker.canGetLocation()) {
            getLatLong();
        }
    }

    private void getLatLong() {
        latitude = gpsTracker.getLatitude();
        longitude = gpsTracker.getLongitude();
        isLatLongPresent = true;
        clearListAndCallFirstPage();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSIONS_REQUEST_LOCATION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getBaseActivity().showToast("Permition Granted HomeFragment");
                    gpsTracker.getLocation();
                    getLatLong();
                } else {
                    getBaseActivity().showToast(getResources().getString(R.string.gps_permittion_denied));
                }
                break;
        }
    }

    private void listMapConversion() {
        if (event.getListMap()==GeneralConstant.LIST_PRODUCT) {
            event.setListMap(GeneralConstant.MAP_PRODUCT);
        } else {
            event.setListMap(GeneralConstant.LIST_PRODUCT);
        }
        EventBus.getDefault().post(event);
    }

    private void address() {
        try {
            Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN)
                    .build(getBaseActivity());
            startActivityForResult(intent, 1);
        } catch (GooglePlayServicesRepairableException e) {
        } catch (GooglePlayServicesNotAvailableException e) {
        }
    }



    private void checkCurrentLatLogAndCallApi(int eventMeetingPageNumber) {
        if (isLatLongPresent) {
            callApiForProduct(eventMeetingPageNumber);
        } else {
            getBaseActivity().showToast(getResources().getString(R.string.please_select_location_for_product));
        }
    }


    @Override
    public void onSuccess(BaseResponse response, int requestCode) {

        if (CommonUtils.isNotNull(response)) {
            if (response instanceof MeetingEventResponseData) {
                MeetingEventResponseData meetingEventResponseData = (MeetingEventResponseData) response;
                if (CommonUtils.isNotNull(meetingEventResponseData)) {
                    MeetingEventDetailResponse meetingEventDetailResponse = meetingEventResponseData.getData();
                    if (CommonUtils.isNotNull(meetingEventDetailResponse)) {

                    }
                }
            }
        }


    }


    private void productResponse(MeetingEventDetailResponse response) {
        if (CommonUtils.isNotNull(response.getContentList())) {
            productList.addAll(response.getContentList());
        }
        EventBus.getDefault().post(event);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                try {
                    // retrive the data by using getPlace() method.
                    Place place = PlaceAutocomplete.getPlace(getBaseActivity(), data);
                    LatLng latLng = place.getLatLng();
                    latitude = latLng.latitude;
                    longitude = latLng.longitude;
                    isLatLongPresent = true;
                    clearListAndCallFirstPage();
                } catch (Exception ex) {

                }

            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(getBaseActivity(), data);
                // TODO: Handle the error.
                Log.e("Tag", status.getStatusMessage());

            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
    }

    private void clearListAndCallFirstPage() {
        productList.clear();
        pageNumber = 1;
        checkCurrentLatLogAndCallApi(1);
    }
}
