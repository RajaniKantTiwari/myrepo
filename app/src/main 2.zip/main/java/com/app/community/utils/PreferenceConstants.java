package com.app.community.utils;

/**
 * Created by arvind on 01/11/17.
 */

public interface PreferenceConstants {
    String TOKEN = "token";
    String USER_NAME = "user_name";
    String DEFAULT = "";
    String USER_LATITUDE = "user_latitude";
    String USER_LONGITUDE = "user_longitude";
}
