package com.app.community.network.response.dashboard.feed;

/**
 * Created by Amul on 28/12/17.
 */

public class FeedResponse {
}
