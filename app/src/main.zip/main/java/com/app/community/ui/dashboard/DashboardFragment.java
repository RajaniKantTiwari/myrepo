package com.app.community.ui.dashboard;

import android.content.Context;

import com.app.community.injector.component.AuthenticationComponent;
import com.app.community.ui.authentication.AuthenticationActivity;
import com.app.community.ui.base.BaseFragment;


/**
 * Created by rajnikant on 06/11/17.
 */

public abstract class DashboardFragment extends BaseFragment {
    private AuthenticationActivity mActivity;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof AuthenticationActivity) {
            AuthenticationActivity activity = (AuthenticationActivity) context;
            this.mActivity = activity;
            activity.onFragmentAttached();
        }
    }

    public AuthenticationComponent getActivityComponent() {
        if (mActivity != null) {
            return mActivity.getActivityComponent();
        }
        return null;
    }

}
