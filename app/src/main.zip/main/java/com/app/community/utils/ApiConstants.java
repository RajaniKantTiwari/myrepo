package com.app.community.utils;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.app.community.utils.ApiConstants.FRAGMENTS.EBOOK;
import static com.app.community.utils.ApiConstants.FRAGMENTS.FEED;
import static com.app.community.utils.ApiConstants.FRAGMENTS.JOURNAL;
import static com.app.community.utils.ApiConstants.FRAGMENTS.LOGIN_FRAGMENT;
import static com.app.community.utils.ApiConstants.FRAGMENTS.LOGIN_FRAGMENT_CHILD;
import static com.app.community.utils.ApiConstants.FRAGMENTS.MEETINGS;
import static com.app.community.utils.ApiConstants.FRAGMENTS.PROFILE;


/**
 * Created by arvind on 01/11/17.
 */

public interface ApiConstants {
   int HTTP_RESPONSE_CODE = 200;
   String AUTHORIZATION ="Authorization";
    String IS_FIRST = "isfirst_time";
    String IMG_RES_ID = "img_res_id";
    String HDR_RES_ID = "hrd_res_id";
    String DSC_RES_ID = "des_res_id";
    String IS_GET_START = "is_started";
    String SUCCESS = "success";

    @IntDef({LOGIN_FRAGMENT,LOGIN_FRAGMENT_CHILD,JOURNAL,EBOOK,PROFILE,FEED,MEETINGS})
   @Retention(RetentionPolicy.SOURCE)
    @interface FRAGMENTS {
        int JOURNAL=0;
        int EBOOK=1;
        int PROFILE=2;
        int FEED=3;
        int MEETINGS=4;
      int LOGIN_FRAGMENT = 6;
      int LOGIN_FRAGMENT_CHILD=7;


    }
}
