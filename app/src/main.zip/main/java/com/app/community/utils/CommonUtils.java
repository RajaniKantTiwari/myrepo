package com.app.community.utils;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.widget.Toast;

import com.app.community.ui.WelcomeScreenActivity;
import com.app.community.ui.dialogfragment.CustomDialogFragment;

/**
 * Created by arvind on 01/11/17.
 */

public class CommonUtils {
    public static int convertDpToPx(int dp, Context context) {
        return Math.round(dp * (context.getResources().getDisplayMetrics().xdpi / DisplayMetrics.DENSITY_DEFAULT));

    }
    /**
     * Show toast message for long time
     *
     * @param context
     * @param msg
     */
    public static void showToastLong(Context context, String msg) {
        if (!TextUtils.isEmpty(msg)) {
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
        }
    }

    public static void showDialog(AppCompatActivity activity, Bundle bundle,CustomDialogFragment.CustomDialogListener listener) {
        FragmentManager fm = activity.getSupportFragmentManager();
        CustomDialogFragment alertdFragment = new CustomDialogFragment();
        alertdFragment.DialogListener(listener);
        alertdFragment.setArguments(bundle);
        // Show Alert CustomDialogFragment
        alertdFragment.show(fm, "");
    }

    public static boolean isNotNull(Object object) {
        return object!=null;
    }
}
