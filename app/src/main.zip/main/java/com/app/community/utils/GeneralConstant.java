package com.app.community.utils;

/**
 * Created by arvind on 21/12/17.
 */

public interface GeneralConstant {
    int PERMISSIONS_REQUEST_LOCATION = 99;
    long SPLASH_TIME=3000;
    String TITLE = "title";
    String USER_NAME = "user_name";
    String VISIBLE = "visible";
    String MOBILE_NUMBER = "mobile_number";
}
